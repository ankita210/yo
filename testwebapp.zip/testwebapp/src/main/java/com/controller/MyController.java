package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Contact;
import com.service.MyServiceIntf;

@Controller("mycontroller")
public class MyController {
	@Autowired
	MyServiceIntf myService;
	
	public MyController(){
		System.out.println("MyController created");
	}
	@RequestMapping(value = "/my", method = RequestMethod.GET)
	public void disp(){
		System.out.println("sdfsdfsdfsdf");
	}
	@RequestMapping(value = "/contact", method = RequestMethod.POST)
	public ModelAndView insertContact( HttpServletRequest request, HttpServletResponse response) {
        String name = request.getParameter("name");
        String info = request.getParameter("info");
        Contact contact = new Contact();
        contact.setInfo(info);
        contact.setName(name);
        boolean flag = myService.insertContact(contact);
        ModelAndView mav = new ModelAndView();
     //   mav.addObject("name", name);
        
        
        //Myuser myuser=new Myuser();
        
        
      /*  if(flag)
        mav.addObject("status","Thanks...message is accepted");
        else
        	mav.addObject("status", "Sorry...message is not accepted");*/
        mav.setViewName("contactreport");
        return mav;
}

}