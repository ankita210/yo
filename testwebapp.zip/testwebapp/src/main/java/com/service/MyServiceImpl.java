package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.MyDaoIntf;
import com.model.Contact;

@Service("myService")
public class MyServiceImpl implements MyServiceIntf {
	@Autowired
    MyDaoIntf myDao;
	public boolean insertContact(Contact contact) {
		System.out.println("Service is called");
		boolean flag = myDao.insertContact(contact);
		return flag;
	}

}
