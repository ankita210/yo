package com.service;

import com.model.Contact;

public interface MyServiceIntf {

	public boolean insertContact(Contact contact);
		
	}

