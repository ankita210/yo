package com.dao;

import org.springframework.stereotype.Repository;

import com.model.Contact;
@Repository("myDao")
public class MyDaoImpl implements MyDaoIntf {

	public boolean insertContact(Contact contact) {
		System.out.println("dao called");
		return true;
	}

}
