package com.dao;

import com.model.Contact;

public interface MyDaoIntf {

	public boolean insertContact(Contact contact);
	
	
}
